### Algorithm: Final configuration
*Why this configuration: the simpler of the candidates that are not worse than FULL (FINAL).*

**Input:** a CVRP instance with a mixed fleet (diesel, clean), a time budget, population size $N$.  
**Objectives:** $f_1$ = total distance, $f_2$ = total true CO$_2$ (depends on the load on each arc).  
**Individual:** a solution (routes with vehicle types) and a weight $w \in [0, 1]$ ($w = 1$: only distance, $w = 0$: only CO$_2$).

1. **Anchors.** Solve the two single-objective problems (minimum distance, minimum surrogate CO$_2$) with PyVRP for 2 s each. *[kept: needed on some instances: worse without it on 2 of 4 instances, mean Â12 = 0.80]*
2. **Initial population.** Give the $N$ individuals weights spread evenly over $[0, 1]$; build for each a random solution whose diesel/clean mix matches its weight, and educate it (step 3.4), then insert the two anchor solutions.
3. **Repeat until the time budget is used:**
    1. **Selection:** choose parents by binary tournament (non-dominated rank, then crowding distance).
    2. **Crossover:** the child keeps a random subset of parent A's routes; the remaining customers follow in parent B's route order. *[kept: needed: worse without it on 3 of 4 instances, mean Â12 = 0.86]*
    3. **Weight:** the child inherits the weight $w$ of parent A. *[kept: needed on some instances: worse without it on 1 of 4 instances, mean Â12 = 0.67]*
    4. **Education** of the child, with its weight $w$:
        - **Local search** with one PyVRP engine, on distance or on surrogate CO$_2$ (chosen at random).
        - **Reorder:** change the order of the customers inside each route (segment reversal, relocation) to reduce $w \cdot$ distance $+ (1 - w) \cdot$ true CO$_2$. *[kept: no effect alone: worse without it on 0 of 4 instances, mean Â12 = 0.61]*
    5. **Survival:** evaluate $f_1$ and true $f_2$; remove duplicates; keep the best $N$ by non-dominated sorting and crowding distance (NSGA-II).
4. **Output:** all non-dominated feasible solutions found during the run.

**Removed from the full algorithm:**

- Route-level mutation: inconclusive, leans harmful: worse without it on 0 of 4 instances, mean Â12 = 0.35.
- Split: no effect alone: worse without it on 0 of 4 instances, mean Â12 = 0.55.
- Normalization: no effect alone: worse without it on 0 of 4 instances, mean Â12 = 0.49.
- Dual-engine LS: no effect alone: worse without it on 0 of 4 instances, mean Â12 = 0.36.
- Intensification: no effect alone: worse without it on 0 of 4 instances, mean Â12 = 0.47.
