"""Run the ablation study in parallel.

Usage (from the code_gvrp/ folder, in a terminal, NOT inside Jupyter):

    python run_ablation.py --stage stage1 --workers 6
    python run_ablation.py --stage stage1 --pilot          # quick check first
    python run_ablation.py --stage stage2 --workers 6      # what notebook 10.6 planned
    python run_ablation.py --stage final --workers 6       # FINAL from notebook 10.9
    python run_ablation.py --collect                       # merge results only

Every (config, instance, seed) run is one job and writes one JSON file:

    results_ablation/raw/<config>/<instance>/seed_<s>.json

A job whose file already exists is skipped, so the script can be stopped and
restarted at any time (resuming). After all jobs, the JSON files are merged into
CSV files in results_ablation/ for the analysis notebook.
"""

import os

# One thread per worker. Must be set BEFORE numpy / numba are imported,
# otherwise every worker spawns threads for all cores and they fight.
for _var in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
             "NUMBA_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(_var, "1")

# Fixed hash seed for the worker processes (they are started with "spawn" and
# read it at startup). Python otherwise randomizes hashing per process, which
# changes some internal orderings and makes a seed less reproducible.
os.environ.setdefault("PYTHONHASHSEED", "0")

import argparse
import csv
import glob
import json
import multiprocessing
import platform
import random
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
from pymoo.core.callback import Callback

import ablation_configs as A

OUT_DIR = "results_ablation"
RAW_DIR = f"{OUT_DIR}/raw"

# How many snapshots of the front each run records, evenly spaced in time.
# Enough for a smooth HV-over-time curve, small enough that 400 runs stay
# around 30 MB of JSON.
N_FRONT_SNAPSHOTS = 40


def _nondominated(P):
    """Distinct non-dominated rows of an (n, 2) array."""
    P = np.unique(np.asarray(P, float), axis=0)
    keep = [i for i in range(len(P))
            if not np.any(np.all(P <= P[i], axis=1) & np.any(P < P[i], axis=1))]
    return P[keep]


class FrontTrace(Callback):
    """The non-dominated set of every feasible point found so far, recorded
    every `every_s` seconds, for the HV-over-time plots.

    Read-only: it changes nothing in the population and draws no random
    numbers, so the search itself is identical with or without it. The front
    is kept incrementally (a few dozen points), so the cost per generation is
    negligible.
    """

    def __init__(self, rows, t0, every_s):
        super().__init__()
        self.rows, self.t0, self.every_s = rows, t0, every_s
        self.front = np.empty((0, 2))
        self._next = 0.0

    def _update(self, pop):
        pts = [raw[:2] for ind in pop
               if (raw := ind.get("F_raw")) is not None
               and np.isfinite(raw[0]) and raw[2] == 0]
        if pts:
            self.front = _nondominated(np.vstack([self.front, pts]))

    def notify(self, algorithm):
        self._update(algorithm.pop)
        if time.perf_counter() - self.t0 >= self._next:
            self.snapshot()
            self._next = time.perf_counter() - self.t0 + self.every_s

    def finish(self, pop):
        """Last snapshot after the run: includes what the callbacks did in
        the final generation, so the curve ends at the reported front."""
        self._update(pop)
        self.snapshot()

    def snapshot(self):
        if len(self.front):
            self.rows.append(dict(elapsed_s=round(time.perf_counter() - self.t0, 2),
                                  front=np.round(self.front, 4).tolist()))


# ---------------------------------------------------------------
# ONE RUN
# ---------------------------------------------------------------

def apply_switches(G, cfg):
    """Set EVERY module-level switch in gvrp.nsga2 for this configuration.

    Worker processes are reused across jobs, so a switch that is not set
    explicitly would keep the value of the previous job.
    """
    G.PERSISTENT_WEIGHT = bool(cfg["persistent_weight"])
    G.CROSSOVER_TYPE = str(cfg["crossover"])
    G.MUT_RATE = float(cfg["mut_rate"])
    G.MUTATION_MOVE_PROBS = dict(cfg["mutation_moves"])
    G.SPLIT_PROB = float(cfg["split_prob"])
    G.USE_BOTH_ENGINES = bool(cfg["dual_engine"])
    G.USE_REORDER = bool(cfg["use_reorder"])

    probs = list(G.MUTATION_MOVE_PROBS.values())
    assert abs(sum(probs) - 1.0) < 1e-9, "mutation_moves must sum to 1"


def calibrate_from_population(dls, problem, X, G):
    """Normalization WITHOUT anchors: take the objective spans from the
    non-dominated feasible points of the initial population.

    Uses the same idea as RecalibrateScales (which then keeps refining the
    scales every 5 generations), so the no_anchors variant still normalizes;
    it just has to estimate the spans from worse solutions.
    """
    pts = []
    for row in X:
        m = G.evaluate_solution(row[0], problem.vrp_data, problem.Q_by_type,
                                problem.n_diesel, problem.n_clean)
        if m is not None and m[2] == 0.0:
            pts.append((m[0], m[1]))
    front = G.pareto_filter(pts)
    if len(front) >= 2:
        F = np.asarray(front, float)
        d_span = float(F[:, 0].max() - F[:, 0].min())
        c_span = float(F[:, 1].max() - F[:, 1].min())
        ref = (float(np.median(F[:, 0])), float(np.median(F[:, 1])))
        if d_span > 1e-6 and c_span > 1e-6:
            dls.set_scales(d_span, c_span, ref=ref, verbose=False)
            return "population"
    if pts:
        # Fallback: the same rule calibrate_from_anchors uses when the anchor
        # ratio is implausible (15% of the best distance, ratio 3.30).
        d_span = 0.15 * min(p[0] for p in pts)
        dls.set_scales(d_span, 3.30 * d_span, verbose=False)
        return "fallback"
    return "none"


def run_one(job):
    """Run one configuration on one instance with one seed. Returns a dict
    that is also written to disk as JSON."""
    # Imported here so that each worker process imports (and configures)
    # the solver itself.
    import run_experiments as R
    from gvrp import nsga2 as G
    from gvrp import config as C
    from pymoo.algorithms.moo.nsga2 import NSGA2
    from pymoo.optimize import minimize

    name, cfg, inst, seed, budget = (job["config"], job["cfg"], job["instance"],
                                     job["seed"], job["budget"])
    apply_switches(G, cfg)

    data, Q_by_type, fleet = R.setup(inst)
    Kd, Kc = fleet["diesel"], fleet["clean"]

    t0 = time.perf_counter()        # the budget clock starts here, as in run_experiments

    dist_data, co2_data = G.build_problem_datas(data, Kd, Kc, Q_by_type)
    dls = G.DualLocalSearch(dist_data, co2_data, Q_by_type, Kd, Kc,
                            seed=seed, nb_size=G.LS_NEIGHBOURHOOD_SIZE,
                            time_budget=float(budget))
    problem = G.GreenVRPProblem(dist_data, Q_by_type, Kd, Kc)

    # --- anchors and normalization, now independent of each other ---
    # In run_experiments.py both hang on CALIBRATE_SCALES. Here:
    #   anchors on,  norm on : original behaviour
    #   anchors on,  norm off: anchors inserted, scales reset to 1.0
    #   anchors off, norm on : scales estimated from the initial population
    #   anchors off, norm off: nothing
    np.random.seed(seed)            # sampling happens before minimize() seeds pymoo
    anchor_d = anchor_c = None
    scale_source = "none"
    if cfg["use_anchors"]:
        anchor_d, anchor_c, _, _ = G.calibrate_from_anchors(dls, problem, seed=seed)
        scale_source = "anchors"
        if not cfg["use_normalization"]:
            dls.dist_scale = dls.co2_scale = 1.0
            scale_source = "none"

    init_X = G.VRPSampling(dls)._do(problem, C.POP_SIZE)

    if anchor_d is not None:
        init_X[0, 0], init_X[0, 1] = anchor_d, 1.0
        init_X[1, 0], init_X[1, 1] = anchor_c, 0.0

    if cfg["use_normalization"] and not cfg["use_anchors"]:
        scale_source = calibrate_from_population(dls, problem, init_X, G)
    initial_scales = (dls.dist_scale, dls.co2_scale)

    algorithm = NSGA2(
        pop_size=C.POP_SIZE,
        sampling=init_X,
        crossover=G.VRPCrossover(dls, prob=G.CX_PROB),
        mutation=G.VRPMutation(dls, rate=G.MUT_RATE),
        eliminate_duplicates=G.VRPDuplicateElimination(),
    )

    # --- callbacks: same order as make_callbacks + run_experiments ---
    # The archive is kept in EVERY configuration: it only changes which points
    # are reported, and must be identical across variants to compare fairly.
    trace_rows, front_rows = [], []
    archive = G.ParetoArchive()
    # Right after the archive, so it sees each generation exactly as the archive does.
    front_trace = FrontTrace(front_rows, t0, budget / N_FRONT_SNAPSHOTS)
    stack = [archive, front_trace]
    extremes = None
    if cfg["use_intensification"]:
        extremes = G.IntensifyExtremes(dls, problem,
                                       passes=G.EXTREME_INTENSIFY_PASSES,
                                       every=G.EXTREME_INTENSIFY_EVERY)
        stack += [extremes,
                  G.IntensifyElite(dls, problem, every=5, passes=1),
                  G.PreserveExtremes(problem)]
    stack.append(R.Trace(trace_rows, inst, seed, t0))
    if cfg["use_normalization"]:
        stack.append(G.RecalibrateScales(dls))
    callback = G.FanOut(stack)

    res = minimize(problem, algorithm, R.WallClock(t0, budget),
                   seed=seed, verbose=False, copy_algorithm=False,
                   callback=callback)
    elapsed = time.perf_counter() - t0
    front_trace.finish(res.algorithm.pop)

    # --- final front: population + archive, exactly as run_experiments ---
    results = []
    for row in np.atleast_2d(res.X):
        m = G.evaluate_solution(row[0], dist_data, Q_by_type, Kd, Kc)
        if m is not None and m[2] == 0.0:
            results.append((float(m[0]), float(m[1]), R.solution_routes(row[0])))
    known = {(f1, f2) for f1, f2, _ in results}
    results += [(f1, f2, []) for f1, f2 in archive.front() if (f1, f2) not in known]

    keep = R.nondominated_idx([(f1, f2) for f1, f2, _ in results]) if results else []
    front, n_bad = [], 0
    for i in keep:
        f1, f2, routes = results[i]
        ok, reason = (R.validate(routes, data, Q_by_type, fleet)
                      if routes else (True, "no routes recorded"))
        n_bad += not ok
        front.append(dict(f1=f1, f2=f2, feasible=int(ok),
                          n_routes=len(routes) if routes else None,
                          n_diesel=sum(t == "diesel" for _, t in routes) if routes else None))

    # --- diagnostics: WHY a component matters, not only WHETHER ---
    counters = dict(
        n_gen=int(res.algorithm.n_gen),
        n_evals=int(res.algorithm.evaluator.n_eval),
        ls_calls_dist=dls.calls["dist"], ls_calls_co2=dls.calls["co2"],
        splits=dls.splits["dist"] + dls.splits["co2"],
        split_repartitions=dls.repartitions,
        split_fallbacks=dls.split_fallbacks,
        split_time_s=round(dls.split_time, 3),
        engine_winner_dist=dls.outcomes["dist"],
        engine_winner_co2=dls.outcomes["co2"],
        engine_both_nondominated=dls.outcomes["random"],
        reorder_calls=dls.intra_calls, reorder_changed=dls.intra_changed,
        ls_time_left_s=round(dls.remaining, 2),
        extremes_attempts=(sum(extremes.attempts.values()) if extremes else 0),
        extremes_improvements=(sum(extremes.improvements.values()) if extremes else 0),
        extremes_gain_dist=(extremes.gains["dist"] if extremes else 0.0),
        extremes_gain_co2=(extremes.gains["co2"] if extremes else 0.0),
        final_dist_scale=dls.dist_scale, final_co2_scale=dls.co2_scale,
        initial_dist_scale=initial_scales[0], initial_co2_scale=initial_scales[1],
        scale_source=scale_source,
        final_weights=[float(w) for w in np.atleast_2d(res.X)[:, 1]],
    )

    out = dict(config=name, cfg=cfg, instance=inst, seed=seed, budget=budget,
               runtime_s=round(elapsed, 2), n_infeasible=n_bad,
               front=front, counters=counters, trace=trace_rows,
               front_trace=front_rows,
               host=platform.node())

    # The folder travels with the job: worker processes are started fresh
    # ("spawn") and do not see RAW_DIR as changed by main().
    path = f"{job['raw_dir']}/{name}/{inst}/seed_{seed:02d}.json"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(out, fh)
    os.replace(tmp, path)          # atomic: a killed job never leaves half a file
    return out


def safe_run(job):
    try:
        out = run_one(job)
        f = out["front"]
        best = (f"best f1={min(p['f1'] for p in f):.0f} "
                f"best f2={min(p['f2'] for p in f):.1f}") if f else "EMPTY FRONT"
        return (f"{job['config']:<16} {job['instance']:<11} seed {job['seed']:>2} "
                f"{out['runtime_s']:6.1f}s gens={out['counters']['n_gen']:>4} "
                f"|P|={len(f):>3} {best}"
                + (f"  {out['n_infeasible']} INFEASIBLE" if out["n_infeasible"] else ""))
    except Exception:
        return f"FAILED {job['config']} {job['instance']} seed {job['seed']}\n{traceback.format_exc()}"


def worker_init():
    # Compile the numba kernels once per worker, before any run is timed.
    from gvrp import nsga2 as G
    G.warm_up_split()


# ---------------------------------------------------------------
# MERGE INTO CSV
# ---------------------------------------------------------------

def collect():
    files = sorted(glob.glob(f"{RAW_DIR}/*/*/seed_*.json"))
    if not files:
        print("nothing to collect yet")
        return

    runs, counters, trace, fronts = [], [], [], []
    for path in files:
        with open(path) as fh:
            r = json.load(fh)
        key = dict(instance=r["instance"], algorithm=r["config"], seed=r["seed"])
        for k, p in enumerate(r["front"], start=1):
            runs.append(dict(**key, runtime_s=r["runtime_s"], f1=p["f1"], f2=p["f2"],
                             feasible=p["feasible"], n_routes=p["n_routes"],
                             n_diesel=p["n_diesel"]))
        c = {k: v for k, v in r["counters"].items() if k != "final_weights"}
        w = r["counters"].get("final_weights", [])
        counters.append(dict(**key, runtime_s=r["runtime_s"], front_size=len(r["front"]),
                             n_infeasible=r["n_infeasible"],
                             final_weight_std=float(np.std(w)) if w else np.nan,
                             **c))
        for snap in r.get("front_trace", []):      # absent in runs made before it existed
            for f1, f2 in snap["front"]:
                fronts.append(dict(**key, elapsed_s=snap["elapsed_s"], f1=f1, f2=f2))
        for t in r["trace"]:
            trace.append(dict(**key, elapsed_s=t["elapsed_s"],
                              best_f1=t["best_f1"], best_f2=t["best_f2"]))

    def dump(rows, path):
        with open(path, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)

    dump(runs, f"{OUT_DIR}/runs.csv")
    dump(counters, f"{OUT_DIR}/counters.csv")
    if trace:
        dump(trace, f"{OUT_DIR}/convergence.csv")
    if fronts:
        dump(fronts, f"{OUT_DIR}/front_trace.csv")
    print(f"collected {len(files)} runs -> {OUT_DIR}/runs.csv, counters.csv, "
          "convergence.csv, front_trace.csv")


# ---------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="stage1", choices=A.STAGE_NAMES,
                    help="stage2 and final run what the notebook wrote into the results folder")
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) // 2),
                    help="parallel runs; at most the number of PHYSICAL cores minus one")
    ap.add_argument("--configs", nargs="*", help="only these configs")
    ap.add_argument("--instances", nargs="*", help="only these instances")
    ap.add_argument("--seeds", nargs="*", type=int, help="only these seeds")
    ap.add_argument("--budget", type=float, help="override BUDGET_SECONDS")
    ap.add_argument("--pilot", action="store_true",
                    help="1 instance, 1 seed, 15 s per run, written to results_ablation_pilot/")
    ap.add_argument("--collect", action="store_true", help="only merge existing results")
    ap.add_argument("--out", help="output folder (default results_ablation, "
                                  "or results_ablation_pilot with --pilot)")
    args = ap.parse_args()

    global OUT_DIR, RAW_DIR
    if args.pilot:
        OUT_DIR = "results_ablation_pilot"
    if args.out:
        OUT_DIR = args.out
    RAW_DIR = f"{OUT_DIR}/raw"

    if args.collect:
        collect()
        return

    configs = A.stage_configs(args.stage, OUT_DIR)
    if not configs:
        raise SystemExit(f"{OUT_DIR}/final_config.json not found: run the notebook "
                         "up to Part 10.9 first, it writes the FINAL configuration")
    if args.configs:
        configs = {k: v for k, v in configs.items() if k in args.configs}
    instances = args.instances or A.INSTANCES
    seeds = args.seeds or A.SEEDS
    budget = args.budget or A.BUDGET_SECONDS
    if args.pilot:
        instances, seeds, budget = instances[:1], seeds[:1], args.budget or 15

    jobs = [dict(config=c, cfg=cfg, instance=i, seed=s, budget=budget, raw_dir=RAW_DIR)
            for c, cfg in configs.items() for i in instances for s in seeds]
    todo = [j for j in jobs if not os.path.exists(
        f"{RAW_DIR}/{j['config']}/{j['instance']}/seed_{j['seed']:02d}.json")]

    # Interleave the configurations: if the machine gets slower or busier
    # during the night, every configuration is affected equally.
    random.Random(12345).shuffle(todo)

    # Guard: never mix runs with different budgets or worker counts in one
    # folder. Resuming only makes sense with identical settings.
    for old in glob.glob(f"{OUT_DIR}/metadata_*.json"):
        with open(old) as fh:
            meta = json.load(fh)
        if meta.get("budget") != budget:
            raise SystemExit(f"{old} was run with budget {meta.get('budget')} s, "
                             f"now {budget} s. Use another --out folder.")
        if meta.get("workers") != args.workers:
            print(f"WARNING: {old} used {meta.get('workers')} workers, now "
                  f"{args.workers}. With a wall-clock budget this changes how many "
                  f"generations a run gets. Use the same number unless you have a reason.")

    os.makedirs(RAW_DIR, exist_ok=True)
    with open(f"{OUT_DIR}/metadata_{args.stage}.json", "w") as fh:
        json.dump(dict(stage=args.stage, configs=configs, instances=instances,
                       seeds=seeds, budget=budget, workers=args.workers,
                       machine=platform.platform(), cpu_count=os.cpu_count()),
                  fh, indent=2)

    hours = len(todo) * budget / args.workers / 3600
    print(f"{len(jobs)} jobs, {len(jobs) - len(todo)} already done, {len(todo)} to run "
          f"on {args.workers} workers: about {hours:.1f} h")

    ctx = multiprocessing.get_context("spawn")      # same behaviour on macOS, Linux, Windows
    with ProcessPoolExecutor(max_workers=args.workers, initializer=worker_init,
                             mp_context=ctx) as ex:
        futures = [ex.submit(safe_run, j) for j in todo]
        for k, fut in enumerate(as_completed(futures), start=1):
            print(f"[{k:>4}/{len(todo)}] {fut.result()}", flush=True)

    collect()


if __name__ == "__main__":
    main()
