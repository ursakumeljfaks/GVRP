# Ablation study of the memetic NSGA-II

Everything is explained step by step in **`ablation_study.ipynb`**. Open it
first and work through it in order; this file is only the short version.

## Install

1. Back up your code: `cp -r code_gvrp code_gvrp_original` (from the folder
   that contains `code_gvrp/`).
2. Copy the contents of this package's `code_gvrp/` folder into your
   `code_gvrp/` folder. The package is complete: besides the new and changed
   files it contains unchanged copies of `gvrp/config.py`, `gvrp/emissions.py`,
   `gvrp/weighted_sum.py` (the versions of 17 September) and the four
   instances in `data/CVRP/`. **If you have changed one of those three `.py`
   files since, keep yours and don't copy it.**
3. Same environment as the main experiments: Python 3.12, pyvrp 0.11.3,
   pymoo 0.6.1.6, numba 0.60, plus scipy, pandas and matplotlib.

## The steps

All commands run in a terminal, from `code_gvrp/`. On macOS, put
`caffeinate -i` in front of the long runs so that the Mac does not sleep.

| Step | What | Command | Notebook |
|---|---|---|---|
| 1 | Checks before the big run | `python check_equivalence.py ../code_gvrp_original .` and `python run_ablation.py --pilot --workers 1` | Part 6 |
| 2 | Stage 1: every component switched off in turn, plus a minimal version (440 runs, about 2.4 h) | `python run_ablation.py --stage stage1 --workers 6` | Part 7 |
| 3 | Analysis; the notebook plans Stage 2 | run Parts 8 and 10 | Parts 8, 10.6 |
| 4 | Stage 2: the follow-up runs the notebook asked for | `python run_ablation.py --stage stage2 --workers 6` | Part 9 |
| 5 | The notebook builds the FINAL configuration | rerun Parts 8 and 10 | Part 10.9 |
| 6 | Confirmation: FINAL and the minimal version against the full algorithm | `python run_ablation.py --stage final --workers 6` | Part 10.10 |
| 7 | The notebook writes the chosen algorithm step by step, with the evidence for each step | rerun the whole notebook | Part 10.11 |
| 8 | Report: fill in 10.7, 10.8, 10.12, 10.13 | | Part 10 |

Use the **same number of workers** for every step. A run that stops can
simply be started again: finished runs are skipped.

## What to send back

The notebook run from top to bottom with all outputs, the folder
`results_ablation/` (without `raw/`, unless asked), and the log files
`ablation_*.log`.
