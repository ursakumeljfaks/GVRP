"""Check that the edited code behaves EXACTLY like the original code, apart
from the two deliberate changes to FULL (notebook, Changes 6 and 7).

Usage (from code_gvrp/):
    python check_equivalence.py ../code_gvrp_original .

Change 6 (new default mutation mix) is undone for the check: the old
four-move mix is set explicitly. Change 7 (PreserveExtremes fix) can only
matter in a generation where BOTH corners were lost; the edited code counts
such generations, so a difference can be traced to it.

Both folders are run with the same seed for a fixed number of generations
(not a time budget, which would make the end point random), with the anchors
limited by iterations instead of seconds, and with a fixed PYTHONHASHSEED
(Python randomizes hashing per process, which changes some internal orderings).
Under these conditions a run is exactly reproducible, so if the edits changed
nothing in the default path, the final populations are identical.
"""
import os
import subprocess
import sys

SNIPPET = r'''
import sys, os, numpy as np
os.chdir(sys.argv[1]); sys.path.insert(0, sys.argv[1])
import run_experiments as R
from gvrp import nsga2 as G, config as C
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
# The anchors use PyVRP with a 2-second TIME limit, so their quality depends on
# machine speed and load. For this check only, replace it with a fixed number
# of iterations, so both folders get exactly the same anchors.
import pyvrp.stop as S
S.MaxRuntime = lambda seconds: S.MaxIterations(1000)
G.warm_up_split()
if hasattr(G, "MUTATION_MOVE_PROBS"):       # edited code only: undo Change 6
    G.MUTATION_MOVE_PROBS = {"flip_type": 0.40, "merge": 0.20,
                             "split": 0.20, "block_type": 0.20}
inst, seed = "X-n101-k25", 3
data, Q, fleet = R.setup(inst); Kd, Kc = fleet["diesel"], fleet["clean"]
dd, cd = G.build_problem_datas(data, Kd, Kc, Q)
dls = G.DualLocalSearch(dd, cd, Q, Kd, Kc, seed=seed,
                        nb_size=G.LS_NEIGHBOURHOOD_SIZE, time_budget=1e6)
p = G.GreenVRPProblem(dd, Q, Kd, Kc)
np.random.seed(seed)
ad, ac, _, _ = G.calibrate_from_anchors(dls, p, seed=seed)
X = G.VRPSampling(dls)._do(p, C.POP_SIZE)
X[0, 0], X[0, 1] = ad, 1.0
X[1, 0], X[1, 1] = ac, 0.0
alg = NSGA2(pop_size=C.POP_SIZE, sampling=X,
            crossover=G.VRPCrossover(dls, prob=G.CX_PROB),
            mutation=G.VRPMutation(dls, rate=G.MUT_RATE),
            eliminate_duplicates=G.VRPDuplicateElimination())
cb, _, _ = G.make_callbacks(dls, p, extra=[G.RecalibrateScales(dls)])
res = minimize(p, alg, ("n_gen", 6), seed=seed, verbose=False,
               copy_algorithm=False, callback=cb)
for f1, f2 in sorted(map(tuple, np.round(res.F, 4))):
    print("POINT", f1, f2)
print("DOUBLE", sum(getattr(c, "double_reinjections", 0) for c in cb.callbacks))
'''


def front(folder):
    """(points, number of double reinjections) of one folder's run."""
    env = dict(os.environ, PYTHONHASHSEED="0")
    out = subprocess.run([sys.executable, "-c", SNIPPET, folder],
                         capture_output=True, text=True, env=env)
    if out.returncode != 0:
        raise SystemExit(f"run in {folder} failed:\n{out.stderr[-2000:]}")
    lines = out.stdout.splitlines()
    double = next(int(l.split()[1]) for l in lines if l.startswith("DOUBLE"))
    return [l for l in lines if l.startswith("POINT")], double


if __name__ == "__main__":
    original, edited = sys.argv[1], sys.argv[2]
    (a, _), (b, double) = front(original), front(edited)
    print(f"original: {len(a)} points, edited: {len(b)} points")
    if a == b:
        print("IDENTICAL: apart from Changes 6 and 7, the edits do not change "
              "the full algorithm.")
    elif double > 0:
        print(f"DIFFERENT, but explained: both corners were lost in {double} "
              "generation(s), which is exactly where the PreserveExtremes fix")
        print("(Change 7) acts. Rerun with another seed in SNIPPET to get a "
              "check where it does not trigger.")
    else:
        print("DIFFERENT: an edit changed the default behaviour. Compare the")
        print("changes in nsga2.py with the notebook, Part 4, line by line.")
        for x, y in zip(a, b):
            if x != y:
                print("  first difference:", x, "vs", y)
                break
