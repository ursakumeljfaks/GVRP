"""All ablation configurations in one place.

FULL is the complete algorithm. Every variant is FULL with exactly ONE entry
changed, so any difference to FULL can be attributed to that one component.
The runner (run_ablation.py) sets every switch for every run, so a worker
process never carries a setting over from the previous job.
"""

import json

# ---------------------------------------------------------------
# INSTANCES AND SEEDS
# ---------------------------------------------------------------
# To add an instance: put the .vrp file into data/CVRP/ and add its name here.
INSTANCES = ["X-n101-k25", "X-n106-k14", "X-n110-k13", "X-n115-k10"]
SEEDS = list(range(1, 11))          # 10 seeds, the same for every config
BUDGET_SECONDS = 120                # wall clock per run, identical for all configs

# ---------------------------------------------------------------
# THE FULL ALGORITHM
# ---------------------------------------------------------------
FULL = dict(
    persistent_weight=True,          # Table 1: persistent weight w
    use_anchors=True,                # Table 1: initialization with extreme anchors
    crossover="route",               # Table 1: route-based crossover
    mut_rate=0.50,                   # Table 1: route-level mutation
    mutation_moves={"merge": 0.50, "split": 0.50},   # type moves dropped: Split
                                     # overwrites them (notebook, Change 6)
    split_prob=1.0,                  # Table 1: Split
    use_normalization=True,          # Table 1: objective normalization
    dual_engine=True,                # Table 1: dual-engine local search
    use_reorder=True,                # Table 1: reorder inside each route
    use_intensification=True,        # NOT in Table 1 yet: elite + corner
                                     # intensification and corner preservation
)


def variant(**changes):
    """FULL with some entries changed. Refuses unknown keys, so a typo
    cannot silently produce a copy of FULL."""
    unknown = set(changes) - set(FULL)
    if unknown:
        raise KeyError(f"unknown switch(es): {sorted(unknown)}")
    cfg = dict(FULL)
    cfg.update(changes)
    return cfg


# ---------------------------------------------------------------
# STAGE 1: leave-one-out (always run)
# ---------------------------------------------------------------
STAGE1 = {
    "FULL":            FULL,
    "no_persist_w":    variant(persistent_weight=False),
    "no_anchors":      variant(use_anchors=False),
    "generic_cx":      variant(crossover="giant_tour"),
    "no_mutation":     variant(mut_rate=0.0),
    "no_split":        variant(split_prob=0.0),
    "no_norm":         variant(use_normalization=False),
    "single_engine":   variant(dual_engine=False),
    "no_reorder":      variant(use_reorder=False),
    "no_intensify":    variant(use_intensification=False),
}

# ---------------------------------------------------------------
# THE MINIMAL VERSION (runs with Stage 1)
# ---------------------------------------------------------------
# The simplest algorithm worth presenting: NSGA-II with the route-based
# crossover and an education of Split -> one local search engine -> reorder,
# with normalized objectives. It is NOT a leave-one-out variant: it removes
# anchors, mutation, the dual engine and intensification at once, and is
# compared with FULL as a whole (notebook, Part 3.10 and 10.10).
REFERENCE = {
    "MINIMAL": variant(use_anchors=False, mut_rate=0.0, dual_engine=False,
                       use_intensification=False),
}

# ---------------------------------------------------------------
# STAGE 2: every follow-up the analysis can ask for
# ---------------------------------------------------------------
# Nothing here is edited by hand. After Stage 1, the notebook (Part 10.6)
# writes <results folder>/stage2_plan.json with the names to run, and
# `run_ablation.py --stage stage2` runs exactly those. FULL is NOT rerun:
# Stage 2 is compared against the FULL runs from Stage 1.
STAGE2_ALL = {
    # --- always run: confirms that dropping the type moves cost nothing ---
    "mut_with_type_moves": variant(mutation_moves={
        "flip_type": 0.40, "merge": 0.20, "split": 0.20, "block_type": 0.20}),

    # --- mutation block: only if no_mutation was clearly worse ---
    "mut_merge_only":   variant(mutation_moves={"merge": 1.0}),
    "mut_split_only":   variant(mutation_moves={"split": 1.0}),
    "mut_educate_only": variant(mutation_moves={"none": 1.0}),
    "mut_low_rate":     variant(mut_rate=0.10),

    # --- pairs: only if BOTH members looked unnecessary on their own ---
    "no_anchors_no_intensify":  variant(use_anchors=False, use_intensification=False),
    "no_persist_w_no_norm":     variant(persistent_weight=False, use_normalization=False),
    "no_split_no_norm":         variant(split_prob=0.0, use_normalization=False),
    "single_engine_no_reorder": variant(dual_engine=False, use_reorder=False),
}
ALWAYS_STAGE2 = ["mut_with_type_moves"]
MUTATION_BLOCK = ["mut_merge_only", "mut_split_only", "mut_educate_only", "mut_low_rate"]

# The pairs and the two Stage 1 variants each one combines.
PAIRS = {
    "no_anchors_no_intensify":  ("no_anchors", "no_intensify"),
    "no_persist_w_no_norm":     ("no_persist_w", "no_norm"),
    "no_split_no_norm":         ("no_split", "no_norm"),
    "single_engine_no_reorder": ("single_engine", "no_reorder"),
}

# ---------------------------------------------------------------
# STAGE "final": the configuration the results point to
# ---------------------------------------------------------------
# Written by the notebook (Part 10.9) to <results folder>/final_config.json
# and run with `run_ablation.py --stage final` as the single configuration
# "FINAL", on the same instances and seeds, against the Stage 1 FULL runs.


def _read_json(path, default):
    try:
        with open(path) as fh:
            return json.load(fh)
    except FileNotFoundError:
        return default


def stage_configs(stage, results_dir):
    """The configurations of one stage. Stage 2 and "final" are read from
    the plan files the notebook writes into the results folder, so a plan
    always belongs to the results it was made from."""
    if stage == "stage1":
        return {**STAGE1, **REFERENCE}
    if stage == "stage2":
        names = _read_json(f"{results_dir}/stage2_plan.json", ALWAYS_STAGE2)
        unknown = set(names) - set(STAGE2_ALL)
        if unknown:
            raise KeyError(f"stage2_plan.json names unknown configs: {sorted(unknown)}")
        return {n: STAGE2_ALL[n] for n in names}
    if stage == "final":
        cfg = _read_json(f"{results_dir}/final_config.json", None)
        return {} if cfg is None else {"FINAL": variant(**cfg)}
    raise KeyError(f"unknown stage {stage!r}")


STAGE_NAMES = ["stage1", "stage2", "final"]

# Human-readable names, used in tables and figures.
LABELS = {
    "FULL": "Full algorithm",
    "no_persist_w": "Random weight",
    "no_anchors": "No anchors",
    "generic_cx": "Generic crossover",
    "no_mutation": "No mutation",
    "no_split": "No Split",
    "no_norm": "No normalization",
    "single_engine": "Single engine",
    "no_reorder": "No reorder",
    "no_intensify": "No intensification",
    "mut_with_type_moves": "With type moves",
    "mut_merge_only": "Merge only",
    "mut_split_only": "Split move only",
    "mut_educate_only": "Educate only",
    "mut_low_rate": "Mutation rate 0.1",
    "no_anchors_no_intensify": "No anchors + no intensification",
    "no_persist_w_no_norm": "Random weight + no normalization",
    "no_split_no_norm": "No Split + no normalization",
    "single_engine_no_reorder": "Single engine + no reorder",
    "FINAL": "Final configuration",
    "MINIMAL": "Minimal version",
}

# Which Table 1 component each Stage 1 variant switches off.
COMPONENT_OF = {
    "no_persist_w": "Persistent weight",
    "no_anchors": "Extreme anchors",
    "generic_cx": "Route-based crossover",
    "no_mutation": "Route-level mutation",
    "no_split": "Split",
    "no_norm": "Normalization",
    "single_engine": "Dual-engine LS",
    "no_reorder": "Reorder in route",
    "no_intensify": "Intensification",
}
